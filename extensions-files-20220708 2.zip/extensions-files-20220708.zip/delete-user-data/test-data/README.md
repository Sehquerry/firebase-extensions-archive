# Extensions Test Data

This package will populate some test data for the following extensions:

- delete-user-data

To run the package, you'll need:

1. Your Firebase project ID
2. A service account key for your project

Simply run the command below and follow the prompts:

```
npm run populate
```
