export enum PartitionFieldType {
  DATE = "DATE",
  DATETIME = "DATETIME",
  TIMESTAMP = "TIMESTAMP",
}
