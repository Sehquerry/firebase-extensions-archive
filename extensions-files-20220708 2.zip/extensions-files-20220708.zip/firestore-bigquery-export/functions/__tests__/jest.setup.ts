global.config = () => require("../src/config").default;
